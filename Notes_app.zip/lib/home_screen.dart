import 'package:flutter/material.dart';
import 'main.dart'; // Import main.dart to access Note class and NoteService
import 'add_note_screen.dart';
import 'view_note_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Note> _notes = [];

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  // Load all notes from storage
  void _loadNotes() {
    setState(() {
      _notes = NoteService.getAllNotes();
    });
  }

  // Navigate to add note screen
  void _navigateToAddNote() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddNoteScreen()),
    );

    if (result == true) {
      _loadNotes(); // Refresh list if note was added
    }
  }

  // Navigate to view note screen
  void _navigateToViewNote(Note note) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ViewNoteScreen(note: note)),
    );
  }

  // Delete note
  void _deleteNote(int id) {
    NoteService.deleteNote(id);
    _loadNotes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Notes'),
      ),
      body: _notes.isEmpty
          ? Center(
        child: Text(
          'No notes yet\nTap + to add your first note',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.grey,
            fontSize: 18,
          ),
        ),
      )
          : ListView.builder(
        itemCount: _notes.length,
        itemBuilder: (context, index) {
          final note = _notes[index];
          return Card(
            color: Colors.grey[900],
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              title: Text(
                note.title,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    note.content.length > 50
                        ? '${note.content.substring(0, 50)}...'
                        : note.content,
                    style: TextStyle(color: Colors.grey[300]),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'ID: ${note.id} • ${note.date.day}/${note.date.month}/${note.date.year}',
                    style: TextStyle(
                      color: Colors.green,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              trailing: IconButton(
                icon: Icon(Icons.delete, color: Colors.red),
                onPressed: () {
                  // Show confirmation dialog
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      backgroundColor: Colors.grey[800],
                      title: Text(
                        'Delete Note',
                        style: TextStyle(color: Colors.white),
                      ),
                      content: Text(
                        'Are you sure you want to delete this note?',
                        style: TextStyle(color: Colors.white),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('Cancel'),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                            _deleteNote(note.id);
                          },
                          child: Text(
                            'Delete',
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
              onTap: () => _navigateToViewNote(note),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddNote,
        child: Icon(Icons.add),
      ),
    );
  }
}